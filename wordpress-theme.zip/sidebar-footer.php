<div class="sidebar container-fluid footer">
	<div class="container-fluid">
		<?php dynamic_sidebar('widget-area-footer'); ?>
	</div>
</div>