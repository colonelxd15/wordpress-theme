<ul class="sidebar">
	<?php dynamic_sidebar('default-widget-area'); ?>
</ul>