	<section class="container-fluid before-footer">
		<?php get_sidebar('footer'); ?>
	</section>
	<div class="container-fluid footer"><p class="footertext">BlankSlate Theme</p></div>
	<?php wp_footer(); ?>
	</body>
</html>