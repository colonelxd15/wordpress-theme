note: 
	add permalink to contents ok
	add link to edit content ok
	add single.php ok 
	pagination
	fix search
	