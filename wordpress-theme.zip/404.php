<?php get_header(); ?>
	<section class="container contents">
		<div class="row">
			<div class="col-md-3 contents">
				<?php get_sidebar(); ?>
			</div>
			<div class="col-md-9 contents">
				<h1>
					No Match Found
				</h1>
			</div>
		</div>
	</section>
<?php get_footer(); ?>