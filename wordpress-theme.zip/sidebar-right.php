<ul class="sidebar">
	<?php dynamic_sidebar('widget-area-right'); ?>
</ul>